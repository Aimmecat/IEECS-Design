/*
 * Style.c
 *
 *  Created on: Sep 1, 2021
 *      Author: Aimmecat
 */

#include "myheadfile.h"

ROBOT_STYLE robot_style = {0,0,0};
