/*
 * Style.h
 *
 *  Created on: Sep 1, 2021
 *      Author: Aimmecat
 */

#ifndef CODE_STYLE_H_
#define CODE_STYLE_H_

typedef struct ROBOT_STYLE{
    int16 Xpos;
    int16 Ypos;
    int16 Thpos;
}ROBOT_STYLE;

extern ROBOT_STYLE robot_style;

#endif /* CODE_STYLE_H_ */
