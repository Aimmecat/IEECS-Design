/*
 * Beep.h
 *
 *  Created on: Aug 23, 2021
 *      Author: Aimmecat
 */

#ifndef CODE_BEEP_H_
#define CODE_BEEP_H_

#define BEEP_PIN    D2

void Beep_Init(void);
void Beep_Set_ms(int16 time);

#endif /* CODE_BEEP_H_ */
