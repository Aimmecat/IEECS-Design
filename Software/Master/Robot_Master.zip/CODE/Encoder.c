#include <myheadfile.h>

//����洢��������������
int16 encoder_master_data[2];

//-------------------------------------------------------------------------------------------------------------------
//  @brief              ������������ʼ��
//  @author             Ji Xiaoyu
//  @update             2021-5-19
//  @param              None
//  @return             void
//  Sample usage:       Encoder_Master_Init()
//-------------------------------------------------------------------------------------------------------------------
void Encoder_Master_Init(void){

    timer_quad_init(TIMER_2, TIMER2_CHA_A15, TIMER2_CHB_B3);
    timer_quad_init(TIMER_3, TIMER3_CHA_B4 , TIMER3_CHB_B5);
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief              ��ȡ��������������
//  @author             Ji Xiaoyu
//  @update             2021-5-19
//  @param              None
//  @return             void
//  Sample usage:       Encoder_Master_Get()
//-------------------------------------------------------------------------------------------------------------------
void Encoder_Master_Get(void){

    encoder_master_data[left_encoder]  = timer_quad_get(TIMER_3);       //������ȡֵ
    encoder_master_data[right_encoder] = timer_quad_get(TIMER_2);       //������ȡֵ
    timer_quad_clear(TIMER_2);                                                                                                                      //��ռ�����
    timer_quad_clear(TIMER_3);                                                                                                                      //��ռ�����
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief              ���Է������������
//  @author             Ji Xiaoyu
//  @update             2021-5-19
//  @param              dir �������ŵ�ƽ
//  @return             void
//  Sample usage:       �ڲ�ʹ�� �������
//-------------------------------------------------------------------------------------------------------------------
int Encoder_Dir(int dir){

    if(dir)return 1;
    return -1;
}
